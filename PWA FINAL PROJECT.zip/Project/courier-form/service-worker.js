const cacheName = 'cacheAssets'



//Called when SW gets installed
self.addEventListener('install', (event) => {
    // console.log("SW Installed: ", event);

    //To skip the waiting and making SW activated 
    self.skipWaiting();

    event.waitUntil(
     caches.open(cacheName)
     .then(function(cache) {
         cache.add('/courier-form/');
         cache.add('/courier-form/index.html');
         cache.add('/courier-form/images/logo.png');
         cache.add('/courier-form/css/style.css');
         cache.add('/courier-form/js/script.js');
         cache.add('/courier-form/manifest.json');
   
    })
    );
    
});


// Called when SW gets activated
self.addEventListener('activate', (event) => {
    console.log("SW Activated: ", event);
    event.waitUntil(clients.claim());
    
    //Deleting old caches
     event.waitUntil(
         caches.keys()
            .then(function (cacheNames) {
                for(const item of cacheNames){
                    if(item !== cacheName){
                        caches.delete(item);
                    }
                }
            })
     )

   
});




// Everytime something comes from the web
self.addEventListener('fetch', (event) => {
    
// console.log('FETCH');


event.respondWith(
    fetch(event.request)
        .catch(function(){
            return caches.match(event.request);
        })
    );
    });

    // Stale while Revalidate
    // event.respondWith(
    //     caches.open(cacheName)
    //         .then(function (cache){
    //             return cache.match(event.request)
    //                 .then(function(cachedResponse){
    //                     const fetchedResponse = fetch(event.request)
    //                         .then(function(networkResponse){
    //                             cache.put(
    //                                 event.request,
    //                                 networkResponse
    //                             );
    //                         return networkResponse;
    //                         });
    //                     return cachedResponse || fetchedResponse;
    //                 })
    //         })
    // );


// });