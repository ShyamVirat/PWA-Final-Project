import RequestDB from "./requestdb.js";

const requestDb = new RequestDB();


if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/courier-form/service-worker.js', {scope:'/courier-form/'})
    .then((registration) => {
    console.log('SW Registered:', registration);
    })
    .catch((error) => {
    console.log('Failed. Error:', error);
    });
    }

if('serviceWorker' in navigator){
    navigator.serviceWorker.ready
        .then((registration)=>{
            console.log('Ready', registration);
            const controller = registration.active;
            controller.postMessage('Welcome to Courier Request Webpage')
        })
}

const output = document.getElementById('request-list');

//document.getElementById('viewButton').addEventListener('click',getRequests);



  
// window.onload=getRequests()


  document.getElementById('sendButton').addEventListener('click',addRequest);
  function addRequest(){
    
    const sendName = document.getElementById('sender-name').value;
    const sendNumber = document.getElementById('sender-number').value;
    const receiveName = document.getElementById('receiver-name').value;
    const receiveNumber = document.getElementById('receiver-number').value;
    const sendAddress = document.getElementById('sender-address').value;
    const receiveAddress = document.getElementById('receiver-address').value;
    console.log('SEND NAME:',sendName)

    //console.log(sName," ",sNumber," ",rName," ",rNumber," ",sAddress," ",rAddress);
    // if((sName=='')||(rName=='')||(rNumber=='')||(rAddress=='')){
    //     // alert("Fill Required Fields")
    // }
    // else{
      requestDb.add(sendName,sendNumber,receiveName,receiveNumber,sendAddress,receiveAddress)
        .then((event) => {
          console.log('Add Success !!!',event);
      })
      .catch((errorMessage) => {
          console.log('Failed to add:', errorMessage);
      });
    // }


    //Temporarirly handling data in Indexed Database
    // requestDb.addIndexed(sendName,sendNumber,receiveName,receiveNumber,sendAddress,receiveAddress)
    //     .then((event)=>{
    //         console.log("Add Success!!");
    //     })
    //     .catch((errorMessage)=>{
    //         console.log("Failed to add: ",errorMessage);
    //     });
    
  }
  
  
  function getRequests(){

    requestDb.getAll()
    .then((results)=>{
      console.log('Results: ',results);
      results.forEach((result)=>{
        appendRequest(result);
      });
    })
    .catch((errorMessage)=>{
      console.log('Catch: ', errorMessage);
    });
  }



  function appendRequest(request){
    const elemRequest = document.createElement('div');
    elemRequest.className = 'list-item';
    output.append(elemRequest);

    
    elemRequest.innerHTML = `
      <table>
        <tr>
            <th>SENDER'S NAME:</th>   
            <th>SENDER'S  NUMBER:</th>
            <th>RECEIVER'S NAME:</th>   
            <th>RECEIVER'S NUMBER:</th> 
            <th>SENDER'S ADDRESS:</th>  
            <th>RECEIVER'S ADDRES:</th> 
        </tr>
        <tr>
            <td>${request.sName}</td>
            <td>${request.sNumber}</td>
            <td>${request.rName}</td>
            <td>${request.rNumber}</td>
            <td>${request.sAddress}</td>
            <td>${request.rAddress}</td>
      </span>
      <br>
    `;

  }


  if(navigator.onLine){
      getRequests();
  }
  else{
      alert("You are offline");
  }


 
  const yesElem = document.getElementById('current_location')


  if('Notification' in window && 'serviceWorker' in navigator){
    yesElem.addEventListener('change',()=>{
        const sendAddress = document.getElementById('sender-address');

        if(yesElem.checked== false){
            sendAddress.disabled = false;
        }
        else{
        sendAddress.disabled = true;
        const permission = Notification.permission;
        console.log('Permission:',permission);
        switch(permission){
            case 'granted':
                showMyNotification();
                break;
            
            case 'denied':
                notificationBtn.disabled=true;
                break;
            
            case 'default':
                requestUserPermission();
                break;
        }
    }})
  }
    else{
        notificationBtn.disabled = true;
    }



  function showMyNotification(){
      const options = {
          body: 'Your Address is being populated based on your current location.',
          actions: [
              {
                action: 'confirm',
                title: 'Okay'
            }
          ]
            
      };

      navigator.serviceWorker.ready.then((registration)=>{
          registration.showNotification("Location fetched successfully!",options);
      });
      handleVibrationAPI();
      handleGeolocationAPI();
  }

  function requestUserPermission(){
    Notification.requestPermission()
        .then((permission)=>{
            console.log('User choice: ',permission);
            if(permission === 'granted'){
                showMyNotification();
            }
        })
        .catch((error)=>{
            console.log('Error: ', error);
        });
  }




  function handleVibrationAPI(){
    if('vibrate' in navigator){
        navigator.vibrate(100);
        console.log('Vibrateddd!!!');
    }
    else{
        alert('Vibration not supported on your device!');
    }
  }

  function handleGeolocationAPI() {
    const sendAddress = document.getElementById('sender-address');

      if('geolocation' in navigator){
       console.log(navigator.geolocation);

          navigator.geolocation.getCurrentPosition(
            
            (position) => {
               
                console.log('Current position: ',position);
                sendAddress.value="Lat: "+position.coords.latitude+" Lng: "+position.coords.longitude;
            },


            (error) => {
                console.log('Current position error: ',error);
            }
          );
      }
      else{
          alert('Geolocation API not available on device');
      }
  }