import { getFirestore, collection, addDoc, getDocs,doc,setDoc } from "https://www.gstatic.com/firebasejs/9.8.4/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.8.4/firebase-app.js";
export default class RequestDB {
    constructor() {
        const firebaseConfig = {
            apiKey: "AIzaSyB_WS2YCF2cLU7z1wGeXFRCafHNX3tkDE0",
            authDomain: "info-6128-finalproject.firebaseapp.com",
            projectId: "info-6128-finalproject",
            storageBucket: "info-6128-finalproject.appspot.com",
            messagingSenderId: "931589182420",
            appId: "1:931589182420:web:8683b63dc1197fb526fc41"
          };
        
        const app = initializeApp(firebaseConfig);
        this.db = getFirestore(app);

        console.log('APPPP:',app);
        console.log('DATABASE:::',this.db)


        //Indexed DB code starts
        // console.log('request db');
        // const request = window.indexedDB.open("RequestDB", 1);

        // request.onsuccess=(event)=>{
        //     console.log("Database Opened:",event);
        //     this.db = event.target.result;
        // }

        // request.onerror=(event)=>{
        //     console.log("Error in opening database:",event.target.error.message);
        // }

        // request.onupgradeneeded = event => {
        //     // Save the IDBDatabase interface
        //     const db = event.target.result;
          
        //     // Create an objectStore for this database
        //     const objectStore = db.createObjectStore("requests", { keyPath: "id" });
        //     objectStore.createIndex("sName","sName");
        //     objectStore.createIndex("sNumber","sNumber");
        //     objectStore.createIndex("rName","rName");
        //     objectStore.createIndex("rNumber","rNumber");
        //     objectStore.createIndex("sAddress","sAddress");
        //     objectStore.createIndex("rAddress","rAddress",{unique: true});

        //   };
        
          //Indexed DB code ends
      
    }

    //Adding a Request in the database using Firestore
    add(sName, sNumber, rName, rNumber, sAddress, rAddress) {
    
        const dbCollection = collection(this.db, "requests");
        
        return addDoc(dbCollection, {
            sName: sName,
            sNumber: sNumber,
            rName: rName,
            rNumber: rNumber,
            sAddress: sAddress,
            rAddress: rAddress
            });


    }


    //Returning all Requests using Firestore
    getAll() {

        
        return new Promise((resolve,reject)=>{
            getDocs(collection(this.db,"requests"))
            .then((querySnapshot)=>{
                const results=[];
                querySnapshot.forEach((doc)=>{
                    const data=doc.data();
                    console.log(doc.id,data);
                    results.push({
                        id:doc.id,
                        sName:data.sName,
                        sNumber:data.sNumber,
                        rName: data.rName,
                        rNumber:data.rNumber,
                        sAddress:data.sAddress,
                        rAddress:data.rAddress
                    });
                });
                resolve(results);
            })
            .catch((error)=>{
                reject(error);
            });
        });
    }




//INDEXED DB add and getAll functions

    // addIndexed(sName,sNumber,rName,rNumber,sAddress,rAddress){
    //     return new Promise((resolve,reject)=>{

    //         const transaction = this.db.transaction(['requests'], "readwrite");
    //         const store = transaction.objectStore("requests");
    //         const request = store.add({
    //             id:Date.now(),
    //             sName: sName,
    //             sNumber: sNumber,
    //             rName: rName,
    //             rNumber: rNumber,
    //             sAddress: sAddress,
    //             rAddress: rAddress
    //         }); 

    //         request.onsuccess=(event)=>{
    //             console.log("Record Added Successfully:",event);
    //             resolve(event);
    //         }

    //         request.onerror=(event)=>{
    //             console.log("Error in adding record:",event.target.error.message);
    //             reject(event.target.error.message);
    //         }

    //     });
    // }

    // getAllIndexed(){
        
    //     return new Promise((resolve, reject)=>{
    //         const request = this.db
    //                     .transaction(['requests'], "readwrite")
    //                     .objectStore("requests")
    //                     .getAllIndexed();
    
    //         request.onsuccess=(event)=>{
    //             resolve(event.target.result);
    //         }
                
    //         request.onerror=(event)=>{
    //             reject(event.target.error.message);
    //         }

    //     });

    // }


}